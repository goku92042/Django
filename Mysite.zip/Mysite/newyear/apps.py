from django.apps import AppConfig


class NewyearConfig(AppConfig):
    name = 'newyear'
